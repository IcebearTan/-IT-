#include<stdio.h>
int main(){
	int a;
	scanf("%d",&a);
	(a<60)?printf("C"):(a<=89)?printf("B"):printf("A");
}
