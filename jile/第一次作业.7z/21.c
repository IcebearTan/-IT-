#include<stdio.h>
int main(){
	int x=1,n=1;
	for(n;n<=9;n++){
		x=(x+1)*2;
	}
	printf("%d",x);
} 
